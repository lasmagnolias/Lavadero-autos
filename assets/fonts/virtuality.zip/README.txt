ENGLISH :

This demo font is for PERSONAL USE ONLY! But any donation is very appreciated.

Paypal account for donation: https://www.paypal.me/fachranheit

If you want to use this font for COMMERCIAL,
This Link to purchase the full version and commercial license:

- https://fachranheit.com/product/virtuality/

Thank you :)

===============================================================================================
SPECIAL OFFER!
The Fancy Display font bundle is here!
Get this ultimate bundle with 20+ display fonts for only $24. with a value of more than $250.
plus Extra Bonus VECTOR ILLUSTRATION
don�t miss this opportunity, so you really get big savings by buying this bundle.

- Link: https://fachranheit.com/product/fancy-display-font-bundle/

Thank you :)

==============================================================================================

INDONESIA:

Berhati-hatilah dan luangkan waktu untuk membaca Syarat & Ketentuan dibawah,
sebelum memutuskan untuk menggunakan font secara komersial.
Ketidaktahuan bukanlah alasan untuk suatu pelanggaran hukum.

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

1. Font ini hanya dapat digunakan untuk keperluan "Personal Use", atau untuk keperluan
yang sifatnya tidak komersil, alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font saya. Baik itu untuk Perorangan/Individual, Agensi Desain Grafis, Percetakan, atau Perusahaan/Korporasi.   

2. DILARANG KERAS menggunakan atau memanfaatkan font ini untuk keperluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, atau untuk Kemasan Produk ( baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

3. Menggunakan font ini untuk keperluan/kepentingan komersial, apapun bentuknya TANPA IZIN atau TANPA MEMBELI LISENSI font terlebih dahulu dari saya, selaku Pencipta
dan/atau Pemegang Hak Cipta font, akan dikenakan biaya EXTENDED LICENSE atau 100 kali harga dari harga Lisensi Standard, atau sesuai dengan ketentuan yang telah diatur dalam Undang-Undang Nomor 28 Tahun 2014 Tentang Hak Cipta.

Apabila anda melanggar/menggunakan untuk kebutuhan komersil tanpa membeli lisensinya terlebih dahulu,
anda akan dikenakan biaya minimal Rp 25.000.000 (Dua Puluh Lima Juta Rupiah) 

Terima kasih , mohon saling support ya :)

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi saya:

Email: hi@fachranheit.com
Website: https://fachranheit.com

Thanks
Fachrul - Fachranheit Studio
